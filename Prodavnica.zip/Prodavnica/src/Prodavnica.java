import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class Prodavnica extends Application {
    private static Racun racun = new Racun();
    private static boolean ocitano = false;

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox root = new VBox(10);
        root.setPadding(new Insets(10,10,10,10));
        root.setAlignment(Pos.TOP_CENTER);
        HBox hbSredina = new HBox(10);
        Button btPrikaziAkcije = new Button("Prikazi akcije");

        root.getChildren().addAll(btPrikaziAkcije, hbSredina);

        TextArea taLevo = new TextArea();
        taLevo.setPrefHeight(300);
        taLevo.setEditable(false);

        VBox vbDesno = new VBox(10);
        Label lbSifra = new Label("Sifra");
        TextField tfSifra = new TextField();
        Label lbKomada = new Label("Komada");
        TextField tfKomada = new TextField();

        Button btOtkucaj = new Button("Otkucaj");
        Button btPonisti = new Button("Ponisti");
        Button btZavrsi = new Button("Zavrsi");
        Button btNoviRacun = new Button("Novi racun");

        vbDesno.getChildren().addAll(lbSifra,tfSifra,lbKomada,tfKomada,btOtkucaj,btPonisti,btZavrsi, btNoviRacun);
        hbSredina.getChildren().addAll(taLevo,vbDesno);

        Kasa.ucitajArtikle();
        btPrikaziAkcije.setOnAction(event -> {

            if(!ocitano) {
                ocitano = true;
                List<Artikal> lista = Kasa.artikliNaAkciji();
                Collections.sort(lista);
                taLevo.appendText("Na akciji: \n");
                for (Artikal a : lista) {
                    if (a.getAkcija() instanceof Popust)
                        taLevo.appendText(a + ((Popust) a.getAkcija()).toString() + "\n");
                    else if (a.getAkcija() instanceof Gratis)
                        taLevo.appendText(a + ((Gratis) a.getAkcija()).toString() + "\n");
                    else
                        taLevo.appendText(a + "\n");
                }
                taLevo.appendText("\n");
            }
        });
        btOtkucaj.setOnAction(event -> {
            try {
                int sifra = Integer.parseInt(tfSifra.getText());
                int komada = Integer.parseInt(tfKomada.getText());


                Optional<Artikal> a = Kasa.ocitajArtikal(sifra);
                if (a.equals(Optional.empty()))
                    taLevo.appendText("Ne postoji artikal sa sifrom " + sifra + "\n");
                else {
                    taLevo.appendText("Otkucano: " + a.get().toString() + "\n");
                    racun.dodajStavku(a.get(), komada);
                }
            }
            catch (Exception e){
                taLevo.appendText("Pogresan format unosa\n!");
                tfKomada.clear();
                tfSifra.clear();
                e.getStackTrace();
            }
        });

        btPonisti.setOnAction(event -> {
            int sifra = Integer.parseInt(tfSifra.getText());
            Optional<Artikal> a = Kasa.ocitajArtikal(sifra);

            if (a.equals(Optional.empty()) || !racun.stavke.containsKey(a.get()))
                taLevo.appendText("Ne postoji artikal sa sifrom " + sifra + "\n");
            else {
                taLevo.appendText("Ponisteno: " + a.get().toString() + "\n");
                racun.ukloniStavku(a.get());
            }
        });

        btZavrsi.setOnAction(event -> {
            taLevo.appendText("\n" + racun.toString());
            racun.stavke.clear();
        });

        btNoviRacun.setOnAction(event -> {
            taLevo.clear();
            ocitano = false;
            racun.stavke.clear();
        });

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setTitle("Prodavnica");
        primaryStage.setScene(scene);
        primaryStage.show();


    }
}
