public class Popust extends Akcija{
    private int procenat;

    public Popust(String datumIsteka, int procenat) {
        super(datumIsteka);
        this.procenat = procenat;
    }

    @Override
    public double cenaPoKomadu(double cena, int otkucanoKomada) {
        double br = 1 - (double)procenat / 100;
        return cena/otkucanoKomada * br;
    }

    @Override
    public String toString() {
        return " snizeno " + procenat + "% do " + super.getDatumIsteka() + " .";
    }
}
