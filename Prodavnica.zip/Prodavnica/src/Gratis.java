public class Gratis extends Akcija{
    private int potrebnoKomada;
    private int gratisKomada;

    public Gratis(String datumIsteka, int potrebnoKomada, int gratisKomada) {
        super(datumIsteka);
        this.potrebnoKomada = potrebnoKomada;
        this.gratisKomada = gratisKomada;
    }

    @Override
    public double cenaPoKomadu(double cena, int otkucanoKomada) {
        double vrednost = cena / otkucanoKomada;
        if (otkucanoKomada < potrebnoKomada)
            return otkucanoKomada * vrednost;
        else{
            int brojac = 0;
            int platiti = 0;
            while (brojac != otkucanoKomada){
                brojac++;
                platiti++;
                if(brojac == potrebnoKomada){
                    brojac += gratisKomada;
                }
            }
            return platiti * vrednost;
        }
    }

    @Override
    public String toString() {
        return " na akciji " + (potrebnoKomada + gratisKomada) + " za " + potrebnoKomada + " do " + super.getDatumIsteka() + " .";
    }
}
