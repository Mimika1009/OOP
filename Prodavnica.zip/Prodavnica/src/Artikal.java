public class Artikal implements Comparable<Artikal>{
    private int sifra;
    private String naziv;
    private double cena;
    private Akcija akcija;

    public Artikal(int sifra, String naziv, double cena, Akcija akcija) {
        this.sifra = sifra;
        this.naziv = naziv;
        this.cena = cena;
        this.akcija = akcija;
    }

    public Artikal(int sifra, String naziv, double cena) {
        this.sifra = sifra;
        this.naziv = naziv;
        this.cena = cena;
        this.akcija = null;
    }

    public int getSifra() {
        return sifra;
    }

    public String getNaziv() {
        return naziv;
    }

    public double getCena() {
        return cena;
    }

    public Akcija getAkcija() {
        return akcija;
    }

    @Override
    public String toString() {
        return sifra + " " + naziv + " " + cena + "";
    }

    @Override
    public int compareTo(Artikal o) {
        if (o.akcija == null && akcija != null)
            return 1;
        else if (o.akcija != null && akcija == null)
            return -1;

        if (o.akcija != null && getAkcija() != null) {
            String datum1 = o.akcija.getDatumIsteka();
            String datum2 = o.akcija.getDatumIsteka();
            String[] tokeniO = datum1.split("/");
            String[] tokeniT = datum2.split("/");

            int dan1, dan2, mesec1, mesec2;
            dan1 = Integer.parseInt(tokeniO[0].trim());
            mesec1 = Integer.parseInt(tokeniO[1].trim());

            dan2 = Integer.parseInt(tokeniT[0].trim());
            mesec2 = Integer.parseInt(tokeniT[1].trim());

            if (dan1 > dan2)
                return 1;
            else if (dan1 < dan2)
                return -1;
        }
        return 0;
    }
}
