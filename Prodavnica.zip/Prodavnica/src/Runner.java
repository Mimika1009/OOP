import java.util.Collections;
import java.util.List;

public class Runner {

    public static void main(String[] args) {
        Kasa.ucitajArtikle();
        List<Artikal> artikals = Kasa.getArtikli();
        Collections.sort(artikals);

        List<Artikal> artikals1 = Kasa.artikliNaAkciji();
        for(Artikal a : artikals1){
            System.out.println(a);
        }
    }
}
