import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;

public class Racun {
    protected Map<Artikal, Integer> stavke = new HashMap<>();

    public void dodajStavku(Artikal artikal, int komada){
        System.out.println(artikal);
        if(!stavke.containsKey(artikal))
            stavke.put(artikal,komada);
        else
            stavke.put(artikal,stavke.get(artikal) + komada);
    }

    public Integer ukloniStavku(Artikal artikal){
        if(stavke.containsKey(artikal))
            return stavke.remove(artikal);
        else
            return 0;
    }
    public String stampajStavku(Artikal artikal, int otkucanoKomada){
        return artikal.getNaziv() + " " + otkucanoKomada + " x " + artikal.getCena() +
                " = " + (otkucanoKomada * artikal.getCena());
    }

    @Override
    public String toString() {
        double suma = 0;
        StringJoiner sj = new StringJoiner("\n");
        for(HashMap.Entry<Artikal, Integer> el : stavke.entrySet()){
                sj.add(stampajStavku(el.getKey(), el.getValue()));
                suma += el.getKey().getCena() * el.getValue();
        }
        System.out.println(stavke);
        return sj.toString() + "\nUkupno: " + suma + "\n";
    }
}
