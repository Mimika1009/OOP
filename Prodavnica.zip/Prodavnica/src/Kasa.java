import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Kasa {
    protected static List<Artikal> artikli = new ArrayList<>();

    public static void ucitajArtikle(){
        try {
          List<String> linije = Files.readAllLines(Paths.get("artikli.txt"));
          for(String linija : linije){
                String[] tokeni = linija.split(",");
                int sifra = Integer.parseInt(tokeni[0].trim());
                String ime = tokeni[1].trim();
                double cena = Double.parseDouble(tokeni[2].trim());
                int popust, potrebno, gratis;
                String akcija = null;
                Akcija action = null;
                if(tokeni.length > 3) {
                    if (tokeni[3].contains("/") || tokeni[4].contains("/")) {
                        if (tokeni[3].contains("/"))
                            akcija = tokeni[3].trim();
                        else if (tokeni[4].contains("/"))
                            akcija = tokeni[4].trim();

                        if (tokeni[3].contains("%")) {
                            popust = Integer.parseInt(tokeni[3].substring(0, 2).trim());
                            action = new Popust(akcija, popust);
                        } else if (tokeni[4].contains("%")) {
                            popust = Integer.parseInt(tokeni[4].substring(0, 2));
                            action = new Popust(akcija, popust);
                        }

                        if (tokeni[3].contains("za")) {
                            String[] lines = tokeni[3].split("za");
                            potrebno = Integer.parseInt(lines[1].trim());
                            gratis = Integer.parseInt(lines[0].trim()) - potrebno;
                            action = new Gratis(akcija, potrebno, gratis);
                        } else if (tokeni[4].contains("za")) {
                            String[] lines = tokeni[4].split("za");
                            potrebno = Integer.parseInt(lines[1].trim());
                            gratis = Integer.parseInt(lines[0].trim()) - potrebno;
                            action = new Gratis(akcija, potrebno, gratis);
                        }
                        Artikal a = new Artikal(sifra, ime, cena, action);
                        artikli.add(a);
                    }
                }
                else{
                    Artikal a = new Artikal(sifra,ime,cena);
                    artikli.add(a);
                }
          }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static Optional<Artikal> ocitajArtikal(int sifra){
        for(Artikal a : artikli){
            if(a.getSifra() == sifra)
                return Optional.of(a);
        }
        return Optional.empty();
    }

    public static List<Artikal> artikliNaAkciji(){
        List<Artikal> lista = new ArrayList<>();
        for(Artikal a : artikli){
            if(a.getAkcija() != null)
                lista.add(a);
        }
        return lista;
    }

    public static List<Artikal> getArtikli() {
        return artikli;
    }
}
